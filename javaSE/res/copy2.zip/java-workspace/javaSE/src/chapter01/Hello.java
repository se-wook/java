package chapter01;

public class Hello {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello");

		String str = "hello";
		for (int i = 0; i < 10; i++) {
			str += i;
			System.out.println(str);
		}
		
	}
}
