package chapter05_1;

import chapter05.Customer;

public class PolyTest3 {

	public static void main(String[] args) {
		Customer cust = new VVip();
//		cust.test();
//		cust.service(); // polytest랑 customer랑은 상속관계가 없어서 안됨.
	}

}
	