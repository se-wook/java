package chapter03;

import java.util.Scanner;

public class WhileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int cnt = 0, sum = 0;
//		Scanner sc = new Scanner(System.in);
//		while(true) {
//			cnt++;
//			int num = sc.nextInt();
//			sum += num;
//			if(num >= 100) {
//				System.out.println(sum);
//				System.out.printf("%.1f",(double)sum/cnt);
//				break;
//			}
//		}
	}
}
