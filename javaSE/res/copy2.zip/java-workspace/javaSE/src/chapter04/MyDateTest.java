package chapter04;

public class MyDateTest {

	public static void main(String[] args) {
		MyDate m1 = new MyDate(2017,13,32);
		System.out.println(m1.toString());
	}

}
