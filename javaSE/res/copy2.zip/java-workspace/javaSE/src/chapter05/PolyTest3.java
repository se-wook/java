package chapter05;

import chapter05_1.VVip;

public class PolyTest3 {

	public static void main(String[] args) {
		Customer cust = new VVip();
		cust.test();
		cust.service();
	}

}
